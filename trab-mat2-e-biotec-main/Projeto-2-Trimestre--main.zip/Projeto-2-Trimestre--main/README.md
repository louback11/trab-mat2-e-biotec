# Projeto-2-Trimestre-
Projeto a ser desenvolvido no segundo trimestre na disciplina de Matemática - II.
